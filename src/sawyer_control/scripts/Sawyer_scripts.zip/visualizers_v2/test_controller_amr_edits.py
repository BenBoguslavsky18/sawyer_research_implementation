#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Pose
from intera_core_msgs.msg import InteractionControlCommand, EndpointState
from intera_motion_interface import InteractionOptions
from std_msgs.msg import Empty
import threading


def create_interaction_msg(stiffness, damping, max_stiffness, nullspace_stiffness, interaction_frame, control_mode):
    """
    Creates and configures an InteractionControlCommand message with the given parameters.
    """
    interaction_options = InteractionOptions()

    # Configure interaction control settings
    interaction_options.set_interaction_control_active(True)
    interaction_options.set_K_impedance(stiffness)  # Cartesian stiffness
    interaction_options.set_K_nullspace(nullspace_stiffness)  # Nullspace stiffness
    interaction_options.set_max_impedance(max_stiffness)  # Max stiffness for safety
    interaction_options.set_interaction_control_mode(control_mode)  # Control mode
    interaction_options.set_in_endpoint_frame(False)  # Use endpoint frame
    interaction_options.set_interaction_frame(interaction_frame)  # Interaction frame
    interaction_options.set_disable_damping_in_force_control(False)  # Enable damping
    interaction_options.set_disable_reference_resetting(False)  # Smooth transitions
    interaction_options.set_rotations_for_constrained_zeroG(False)  # Allow full movement

    # Add damping separately (as it is not set in the InteractionOptions directly)
    msg = interaction_options.to_msg()
    msg.D_impedance = damping
    return msg


class CartesianImpedanceController:
    def __init__(self):
        rospy.init_node('dynamic_cartesian_impedance_controller')

        # Initialize stiffness parameters
        self.default_stiffness = [50.0, 50.0, 50.0, 30.0, 30.0, 30.0]
        self.current_stiffness = self.default_stiffness[:]
        self.damping = [8.0, 8.0, 8.0, 2.0, 2.0, 2.0]
        self.nullspace_stiffness = [5.0] * 7
        self.max_stiffness = [False, False, False, False, False, False]
        self.control_mode = [1, 1, 1, 1, 1, 1]

        # Error region of interest
        self.stiffness_region_start = 0.1
        self.stiffness_region_end = 0.2
        self.in_error_region = False

        # Initialize interaction frame (identity pose)
        self.interaction_frame = Pose()
        self.interaction_frame.position.x = 0.0
        self.interaction_frame.position.y = 0.0
        self.interaction_frame.position.z = 0.0
        self.interaction_frame.orientation.w = 1.0

        # ROS Publisher for interaction control
        self.ic_pub = rospy.Publisher('/robot/limb/right/interaction_control_command',
                                      InteractionControlCommand, queue_size=10)

        # ROS Publisher for collision avoidance suppression
        self.collision_pub = rospy.Publisher('/robot/limb/right/suppress_collision_avoidance',
                                             Empty, queue_size=10)

        # Subscribe to endpoint state
        rospy.Subscriber('/robot/limb/right/endpoint_state', EndpointState, self.endpoint_callback)

        # Continuous publishing threads
        self.continue_publishing = True
        self.control_thread = threading.Thread(target=self.publish_control)
        self.control_thread.daemon = True
        self.control_thread.start()

        self.collision_thread = threading.Thread(target=self.suppress_collision_avoidance)
        self.collision_thread.daemon = True
        self.collision_thread.start()

        # Shutdown handler
        rospy.on_shutdown(self.shutdown_handler)

    def publish_stiffness(self):
        """
        Publish the current stiffness values to the robot.
        """
        interaction_msg = create_interaction_msg(self.current_stiffness, self.damping,
                                                 self.max_stiffness, self.nullspace_stiffness,
                                                 self.interaction_frame, self.control_mode)
        self.ic_pub.publish(interaction_msg)

    def endpoint_callback(self, msg):
        """
        Monitor the robot's endpoint position and adjust stiffness dynamically in the error region.
        """
        y_position = msg.pose.position.y

        # Check if robot is in the error region
        if self.stiffness_region_start <= y_position <= self.stiffness_region_end:
            if not self.in_error_region:
                rospy.loginfo("Entering error region. Increasing stiffness for 6 seconds.")
                self.in_error_region = True
                self.start_stiffness_adjustment()
        else:
            if self.in_error_region:
                rospy.loginfo("Exiting error region. Restoring default stiffness.")
                self.in_error_region = False
                self.restore_default_stiffness()

    def start_stiffness_adjustment(self):
        """
        Temporarily increase stiffness for x, y, and z directions for 6 seconds.
        """
        # Increment only x, y, and z stiffness (indices 0, 1, 2)
        self.current_stiffness = [
            min(stiffness + 700, 2000.0) if i < 3 else stiffness
            for i, stiffness in enumerate(self.default_stiffness)
        ]

        # Publish the increased stiffness
        self.publish_stiffness()

        # Restore stiffness after 6 seconds
        rospy.Timer(rospy.Duration(4), lambda event: self.restore_default_stiffness(), oneshot=True)

    def restore_default_stiffness(self):
        """
        Restore the default stiffness values globally.
        """
        self.current_stiffness = self.default_stiffness[:]
        self.publish_stiffness()

    def publish_control(self):
        """
        Continuously publish Cartesian Impedance Control settings.
        """
        rate = rospy.Rate(10)  # Publish at 10 Hz
        while self.continue_publishing and not rospy.is_shutdown():
            self.publish_stiffness()
            rate.sleep()

    def suppress_collision_avoidance(self):
        """
        Continuously suppress collision avoidance by publishing empty messages.
        """
        rate = rospy.Rate(10)  # Publish at 10 Hz
        while self.continue_publishing and not rospy.is_shutdown():
            self.collision_pub.publish(Empty())
            rate.sleep()

    def shutdown_handler(self):
        """
        Switch back to position control mode during shutdown.
        """
        rospy.loginfo("Shutting down. Switching back to position control mode...")
        self.continue_publishing = False  # Stop the publishing threads
        interaction_msg = InteractionControlCommand()
        interaction_msg.header.stamp = rospy.Time.now()
        interaction_msg.interaction_control_active = False
        for _ in range(5):  # Publish multiple times to ensure mode switch
            self.ic_pub.publish(interaction_msg)
            rospy.sleep(0.1)
        rospy.loginfo("Switched to position control mode.")

    def run(self):
        """
        Main loop for the controller.
        """
        rospy.loginfo("Running Dynamic Cartesian Impedance Controller...")
        rospy.spin()


if __name__ == '__main__':
    try:
        controller = CartesianImpedanceController()
        controller.run()
    except rospy.ROSInterruptException:
        rospy.loginfo("ROS interrupt detected. Exiting...")
